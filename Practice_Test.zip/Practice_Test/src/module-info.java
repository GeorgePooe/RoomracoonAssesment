/**
 * 
 */
/**
 * 
 */
module Practice_Test {
	requires org.seleniumhq.selenium.api;
	requires org.seleniumhq.selenium.remote_driver;
	requires org.seleniumhq.selenium.chrome_driver;
}